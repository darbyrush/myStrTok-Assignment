//
//  mystrtok.cpp
//  Homework2
//
//  Created by Darby Rush on 9/22/20.
//  Copyright © 2020 Darby Rush. All rights reserved.
//
#include <iostream>
#include "mystrtok.h"
#include "helper.h"
using namespace std;

char *mystrtok(char *str, const char *delim)
{
    
char *star = nullptr; //save start of string
char *token = nullptr;// find end of string
    
    //find the start of string
    if(str != NULL)
     {
         star = find_first_non_in_the_set(str,delim);//loacting first char in string
     }
     if(str==NULL)
        {
         star = find_first_in_the_set(str, delim);
        }
    //find end of string
if(star != NULL)
{
  token = find_first_in_the_set(star, delim);//loacting end of string
        if(token == NULL)
        {
            return token;
        }
        else if( token != NULL)
        {
            *token = '\0';
        }
}
    return token;
}


