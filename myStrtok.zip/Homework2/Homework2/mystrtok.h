//
//  mystrtok.h
//  Homework2
//
//  Created by Darby Rush on 9/22/20.
//  Copyright © 2020 Darby Rush. All rights reserved.
//

#ifndef MYSTROK_H
#define MYSTROK_H

#include <cstdlib>
#include "helper.h"

char *mystrtok(char *str, const char *delim);

#endif

