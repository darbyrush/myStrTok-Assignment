//
//  main.cpp
//  Homework2
//
//  Created by Darby Rush on 9/17/20.
//  Copyright © 2020 Darby Rush. All rights reserved.
//
#include <iostream>
#include "mystrtok.h"
using namespace std;
//Test

 int main()
 {
 char * end;
 char str[] = "Here is a string";
 cout << str << endl;
 end=mystrtok(str, " ");
 while(end!=NULL)
 {
 cout << end;
 end=mystrtok(NULL, " ");
 }
 return 0;
 }
 

