//
//  helper.cpp
//  Homework2
//
//  Created by Darby Rush on 9/23/20.
//  Copyright © 2020 Darby Rush. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include "helper.h"
using namespace std;

bool is_char_in_the_set(char c, const char *set)
{
    bool t = true;
    bool f = false;
for(int i = 0; set[i] != '\0'; i++)
    {

        if(c == set[i])
        {
        
        return t;
        }
  
    }
    return f;
}





char *find_first_non_in_the_set(char *str, const char *set)
{



    for(int i = 0; *(str + i) != '\0'; i++)
    {
        
        for(int x = 0; *(set + x) != '\0'; x++)
        {
          if(str[i] != set[x])
          {
          return &str[i];
               }
        }

    
    }


return NULL;
}



char *find_first_in_the_set(char *str, const char *set)
{


        for(int i = 0; *(str + i) != '\0'; i++)
        {
                
                for(int x = 0; *(set + x) != '\0'; x++)
                {
                  if(str[i] == set[x])
                  {
                  return &str[i];
                  }
                }

        
        }

    void testing(char* test_string, const char* test_set);

return NULL;

}
