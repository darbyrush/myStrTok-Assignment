//
//  helper.h
//  Homework2
//
//  Created by Darby Rush on 9/23/20.
//  Copyright © 2020 Darby Rush. All rights reserved.
//

#ifndef HELPER_H
#define HELPER_H

#include <cstdlib>


bool is_char_in_the_set(char c, const char *set);

char *find_first_non_in_the_set(char *str, const char *set);

char *find_first_in_the_set(char *str, const char *set);


#endif
