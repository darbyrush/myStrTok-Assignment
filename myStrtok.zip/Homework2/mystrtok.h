#ifndef MYSTROK_H
#define MYSTROK_H

#include <cstdlib>


char *mystrtok(char *str, const char *delim);

#endif
