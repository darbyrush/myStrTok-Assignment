#include <cstring>
#include <iostream>
#include "helper.h"
#include "mystrtok.cpp"
using namespace std;

int main()
{
/*
//TEST ONE
cout << "TEST ONE" << endl;
char test_string[15];
char test_set[10];
char *p; // pointer to the return character
char *q;
char *t;
char *x;

strcpy(test_string, "Hi Everyone!");
strcpy(test_set, "e");
p = find_first_in_the_set(test_string, test_set);
cout << *p << endl;
cout << *(p-1) << endl;
// the above output should e and *(p-1) is v and *(p+1) is r
p = find_first_non_in_the_set(test_string, test_set);
cout << *p << endl; // the output should be H


//TEST TWO	
cout << "TEST TWO" << endl;
strcpy(test_set, "e");
x = find_first_in_the_set(test_string, test_set);
cout << *x << endl;
cout << *(x-1) << endl;
cout << (x+1) << endl;
// the above output should e and *(p-1) is v and *(p+1) is r
x = find_first_non_in_the_set(test_string, test_set);
cout << *x << endl; // the output should be H

//TEST THREE
cout << "TEST THREE" << endl;
strcpy(test_set, "w");
q = find_first_in_the_set(test_string, test_set);
cout << *q << endl; 
q = find_first_non_in_the_set(test_string, test_set);
cout << *q << endl;

//TEST FOUR
cout << "TEST FOUR" << endl;
strcpy(test_set, "?");
t = find_first_in_the_set(test_string, test_set);
cout << *t << endl; 
t = find_first_non_in_the_set(test_string, test_set);
cout << *t << endl;

*/


//MYSTRTOK TEST
cout << "TEST MYSTRTOK" << endl;

    char * end;
    char str[] = "Here is a string";
        cout << str << endl;
        end = mystrtok(str, " ");
        while(end!=NULL)
        {
            cout << end;
            end=mystrtok(NULL, " ");
        }
        




return 0;
}


