#include <iostream>
#include "helper.h"
using namespace std;

char *find_first_non_in_the_set(char *str, const char *set)
{



	for(int i = 0; *(str + i) != '\0'; i++)
	{
		
		for(int x = 0; *(set + x) != '\0'; x++)
		{
		  if(str[i] != set[x])
		  {
		  return &str[i];
     		  }	
		}

	
	}


return '\0';
}



char *find_first_in_the_set(char *str, const char *set)
{


        for(int i = 0; *(str + i) != '\0'; i++)
        {
                
                for(int x = 0; *(set + x) != '\0'; x++)
                {
                  if(str[i] == set[x])
                  {
                  return &str[i];
                  }     
                }

        
        }



return '\0';

}
