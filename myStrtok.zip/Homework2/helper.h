#ifndef MYSTROK_H
#define MYSTROK_H

#include <cstdlib>


char *find_first_non_in_the_set(char *str, const char *set);
char *find_first_in_the_set(char *str, const char *set);


#endif
